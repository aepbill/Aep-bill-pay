# aep-bill-pay-seo-enhanced

SEO-optimized landing page and PDF for **AEP Bill Pay** with phone number **877-218-4132**.

## Files
- `index.html` — Responsive, mobile-friendly landing page
- `AEP-bill-pay.pdf` — Printable PDF with main content
- `.github/workflows/deploy.yml` — Auto deploy to GitHub Pages
- `README.md` — Instructions and SEO tips

## How to deploy
1. Create a new GitHub repo named `aep-bill-pay-seo-enhanced`.
2. Push all files to the `main` branch.
3. GitHub Actions will deploy automatically to GitHub Pages.
4. Verify phone number `877-218-4132` before publishing.
